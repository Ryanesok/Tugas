const clickButton = document.getElementById('clickButton');
const paragraf = document.getElementById('paragraf');

clickButton.addEventListener('click', function(){
    paragraf.style.color = 'blue';
})